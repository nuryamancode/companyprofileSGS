<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2024 <div class="bullet"></div> Satria Global Solusi</a>
    </div>
    <div class="footer-right">

    </div>
</footer>
